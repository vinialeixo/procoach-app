import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useNavigate } from "react-router-dom";
import { AuthLayout } from "@/components/ui/AuthLayout";
import { Field } from "@/components/ui/Field";
import { Button } from "@/components/ui/Button";
import {
  useStartMfaSetup,
  useConfirmMfaSetup,
  type MfaSetupStart,
} from "@/lib/auth";
import "./MfaSetupPage.css";

// T-011: ativação do MFA logo após o registro. O segredo TOTP vem do núcleo
// (contrato assumido, ver lib/auth.ts); aqui exibimos o QR + segredo e
// confirmamos com o primeiro código de 6 dígitos.
const mfaSchema = z.object({
  code: z
    .string()
    .min(6, "O código tem 6 dígitos")
    .max(6, "O código tem 6 dígitos")
    .regex(/^\d+$/, "Use apenas números"),
});
type MfaForm = z.infer<typeof mfaSchema>;

export function MfaSetupPage() {
  const navigate = useNavigate();
  const [setup, setSetup] = useState<MfaSetupStart | null>(null);
  const [serverError, setServerError] = useState<string | null>(null);

  const startMutation = useStartMfaSetup();
  const confirmMutation = useConfirmMfaSetup();

  const form = useForm<MfaForm>({ resolver: zodResolver(mfaSchema) });

  // Ao abrir, pede o segredo TOTP ao núcleo (uma vez).
  useEffect(() => {
    let cancelled = false;
    startMutation
      .mutateAsync()
      .then((result) => {
        if (!cancelled) setSetup(result);
      })
      .catch(() => {
        if (!cancelled)
          setServerError("Não foi possível iniciar a configuração do MFA.");
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function onSubmit(values: MfaForm) {
    setServerError(null);
    try {
      await confirmMutation.mutateAsync({ code: values.code });
      navigate("/login", { replace: true });
    } catch {
      setServerError("Código inválido. Confira o aplicativo autenticador.");
    }
  }

  return (
    <AuthLayout>
      <h1 className="mfa-setup__title">Ativar verificação em duas etapas</h1>
      <p className="mfa-setup__subtitle">
        Escaneie o QR code com seu aplicativo autenticador (ou digite o
        segredo) e confirme com o código gerado.
      </p>

      {setup ? (
        <div className="mfa-setup__secret">
          {/* otpauthUrl pronta para renderizar como QR (lib de QR a definir).
              Por ora mostramos o segredo em texto mono, que já desbloqueia o
              cadastro manual no autenticador. */}
          <p className="mfa-setup__secret-label">Segredo (cadastro manual)</p>
          <code className="mfa-setup__secret-value">{setup.secret}</code>
        </div>
      ) : (
        <p className="mfa-setup__loading">Gerando segredo...</p>
      )}

      <form
        className="mfa-setup__form"
        onSubmit={form.handleSubmit(onSubmit)}
        noValidate
      >
        <Field
          label="Código de verificação"
          inputMode="numeric"
          autoComplete="one-time-code"
          maxLength={6}
          error={form.formState.errors.code?.message}
          {...form.register("code")}
        />

        {serverError && (
          <p className="mfa-setup__server-error" role="alert">
            {serverError}
          </p>
        )}

        <Button type="submit" loading={confirmMutation.isPending}>
          Ativar e concluir
        </Button>
      </form>
    </AuthLayout>
  );
}
